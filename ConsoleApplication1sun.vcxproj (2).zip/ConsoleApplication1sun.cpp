// ConsoleApplication1sun.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

class Investment {      //create class; investment


private:                //set private data members
    double initialInvestmentAmount;
    double monthlyDeposit;
    double annualInterest;
    int numberOfYears;

    double calculateYearEndBalance(double openingBalance, double interestRate) {        //set equation for determining year end balance
        return openingBalance * (1 + (interestRate / 12));
    }

    double calculateYearEndInterest(double openingBalance, double interestRate) {       //set equation for determining year end interest
        return openingBalance * ((interestRate / 12) / 100);
    }

public:                 //set public data members
    Investment(double initialInvestmentAmount, double monthlyDeposit, double annualInterest, int numberOfYears) {
        this->initialInvestmentAmount = initialInvestmentAmount;
        this->monthlyDeposit = monthlyDeposit;
        this->annualInterest = annualInterest;
        this->numberOfYears = numberOfYears;
    }


    void calculateWithoutMonthlyDeposit() {                     // Funciton to calculate and outout balance without a monthly deposit
        double openingBalance = initialInvestmentAmount;
        double interestRate = annualInterest;
        double yearEndBalance, yearEndInterest;

        cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
        cout << fixed << setprecision(2);

        for (int i = 1; i <= numberOfYears; i++) {
            yearEndInterest = calculateYearEndInterest(openingBalance, interestRate);
            yearEndBalance = calculateYearEndBalance(openingBalance, interestRate) + yearEndInterest;

            cout <<"  "<< i << "             " << yearEndBalance << "                    " << yearEndInterest << endl;

            openingBalance = yearEndBalance;
        }
    }

    void calculateWithMonthlyDeposit() {                        // Funciton to calculate and outout balance with a monthly deposit
        double openingBalance = initialInvestmentAmount;
        double interestRate = annualInterest;
        double yearEndBalance, yearEndInterest;

        cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
        cout << fixed << setprecision(2);

        for (int i = 1; i <= numberOfYears; i++) {
            yearEndInterest = calculateYearEndInterest(openingBalance, interestRate);
            yearEndBalance = calculateYearEndBalance(openingBalance + monthlyDeposit, interestRate) + yearEndInterest;

            cout <<"  "<< i << "            " << yearEndBalance << "                       " << yearEndInterest << endl;

            openingBalance = yearEndBalance;
        }
    }

    void displayTable(bool withMonthlyDeposit) {                //loop to display year-end balances and year-end earned interest if no additional monthly deposits are made.
        if (withMonthlyDeposit) {
            cout << "Investment with Monthly Deposits" << endl;
            cout << "----------------------------------------" << endl;
            calculateWithMonthlyDeposit();
        }
        else {
            cout << "Investment without Monthly Deposits" << endl;           // display to show year-end balances and year-end earned interest if additional monthly deposits are made.
            cout << "----------------------------------------" << endl;
            calculateWithoutMonthlyDeposit();
        }
    }
};

int main() {
    double initialInvestmentAmount, monthlyDeposit, annualInterest;
    int numberOfYears;

    cout << "Enter initial investment amount: ";        //initial display menu
    cin >> initialInvestmentAmount;

    cout << "Enter monthly deposit: ";
    cin >> monthlyDeposit;

    cout << "Enter annual interest rate: ";
    cin >> annualInterest;

    cout << "Enter number of years: ";
    cin >> numberOfYears;

    Investment investment(initialInvestmentAmount, monthlyDeposit, annualInterest, numberOfYears);

    cout << endl;

    investment.displayTable(false); //boolean to determine which display to use
    cout << endl;
    investment.displayTable(true);  

    return 0;
}